package com.capg.stepdef;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver driver;

	@Given("^Navigate to Icompass URL$")
	public void navigate_to_Icompass_URL() throws Throwable {

		driver = WebUtil.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com/iCompass/#/";
		driver.get(url);

	}

	@When("^Enter valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void enter_valid_username_and_valid_password(String username, String password) throws Throwable {

		WebElement userTextField = driver.findElement(By.id("userName"));
		WebElement passwordTextField = driver.findElement(By.id("password"));
		userTextField.sendKeys(username);
		passwordTextField.sendKeys(password);
	}

	@Then("^Login Successfully$")
	public void login_Successfully() throws Throwable {

		WebElement loginButton = driver.findElement(By.id("loginButton"));
		loginButton.click();
		driver.close();
	}

	@Given("^Navigate to Google URL$")
	public void navigate_to_Google_URL() throws Throwable {

		driver = WebUtil.getWebDriver();
		String url = "http://www.google.com";
		driver.navigate().to(url);
	}

	@When("^Enter input \"([^\"]*)\"$")
	public void enter_input(String input) throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		WebElement searchfield = driver.findElement(By.name("q"));
		searchfield.sendKeys(input);
		searchfield.sendKeys("\n");
	}

	@Then("^Climate details display$")
	public void climate_details_display() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		System.out.println("Climate details displayed");
		driver.close();
	}

	@When("^click on image link$")
	public void click_on_image_link() throws Throwable {

		WebElement imageLink = driver.findElement(By.className("gb_e"));
		imageLink.click();
	}

	@Then("^Display images page$")
	public void display_images_page() throws Throwable {
		System.out.println("images page displayed");
		driver.close();
	}

}
