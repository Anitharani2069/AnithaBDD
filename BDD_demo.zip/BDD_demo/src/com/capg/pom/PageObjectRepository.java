package com.capg.pom;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

//import cucumber.api.java.Before;

public class PageObjectRepository {

	@FindBy(id = "userName")
	@CacheLookup
	WebElement userNameField;

	@FindBy(how = How.ID, using = "password")
	@CacheLookup
	WebElement passwordField;

	@FindBy(id = "loginButton")
	@CacheLookup
	WebElement loginButton;

//	@Before
	public static WebDriver getWebDriver() {
		String path = "C:\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();
		return driver;
	}

	public PageObjectRepository(WebDriver driver) {
		PageFactory.initElements(driver, this);
	}

	public WebElement getUserNameField() {
		return userNameField;
	}

	public void setUserNameField(WebElement userNameField) {
		this.userNameField = userNameField;
	}

	public WebElement getPasswordField() {
		return passwordField;
	}

	public void setPasswordField(WebElement passwordField) {
		this.passwordField = passwordField;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public void setLoginButton(WebElement loginButton) {
		this.loginButton = loginButton;
	}

}
