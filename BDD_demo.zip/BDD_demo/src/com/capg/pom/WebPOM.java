package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;



public class WebPOM {

	static WebDriver driver;
	
	public static WebDriver getWebDriver() {
		String path = "C:\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		driver =  new ChromeDriver();
		return driver;
	}
	
	public static WebElement getUserField() {
	
		return	driver.findElement(By.id("userName"));
	}
	
	public static WebElement getPasswordField() {
		
		return	driver.findElement(By.id("password"));
	}
	
	public static WebElement getLoginButton() {
		
		return	driver.findElement(By.id("loginButton"));
	}
}
