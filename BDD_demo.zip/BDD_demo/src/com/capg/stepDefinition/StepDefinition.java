package com.capg.stepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.PageObjectRepository;
//import com.capg.pom.WebPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {
	WebDriver driver;
	PageObjectRepository pageRepo;

	@Given("^Open any browser and enter icompass url$")
	public void open_any_browser_and_enter_icompass_url() throws Throwable {

		driver = PageObjectRepository.getWebDriver();
		String url = "https://icompassweb.fs.capgemini.com/iCompass/#/";
		driver.get(url);
		pageRepo = new PageObjectRepository(driver);
	}

	@When("^User enter valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enter_valid_username_and_valid_password(String userName, String password) throws Throwable {

		WebElement userNameField =  pageRepo.getUserNameField();
		userNameField.sendKeys(userName);
		WebElement passwordField = pageRepo.getPasswordField();
		passwordField.sendKeys(password);
	}

	@Then("^Login to icompass successfully$")
	public void login_to_icompass_successfully() throws Throwable {

		WebElement loginButton = pageRepo.getLoginButton();
		loginButton.click();
	}
}
