package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

public class RegisterPOM {
static WebDriver driver;
	
	public static WebDriver getWebDriver()
	{
		driver = WebUtil.getWebDriver();
		return driver;
	}
	
	public static WebElement getFullName()
	{
		return driver.findElement(By.id("txtFullName"));
	}
	
	public static WebElement getEmail()
	{
		return driver.findElement(By.id("txtEmail"));
	}
	
	public static WebElement getMobileNo()
	{
		return driver.findElement(By.id("txtPhone"));
	}
	
	public static WebElement getGender()
	{
		//return driver.findElement(By.xpath("//*[@id=\"gender\"]"));
		return driver.findElement(By.id("gender"));
	}
	
	public static WebElement getCity()
	{
		return driver.findElement(By.name("city"));
	}
	
	public static WebElement getState()
	{
		return driver.findElement(By.name("state"));
	}
	
	public static WebElement getAuthors()
	{
		return driver.findElement(By.name("cvv"));
	}
		
	public static WebElement getButton()
	{
		return driver.findElement(By.id("btnPayment"));
	}
	
	public static WebElement getSubjectCategory()
	{
		return driver.findElement(By.id("txtCardholderName"));
	}
	public static WebElement getPaperName()
	{
		return driver.findElement(By.id("txtDebit"));
	}
	
	public static WebElement getCompanyName()
	{
		return driver.findElement(By.id("txtMonth"));
	}
	public static WebElement getDesignation()
	{
		return driver.findElement(By.id("txtYear"));
	}
	
}
