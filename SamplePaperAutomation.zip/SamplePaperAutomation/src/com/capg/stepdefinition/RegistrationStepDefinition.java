package com.capg.stepdefinition;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.capg.pom.LoginPOM;
import com.capg.pom.RegistrationPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RegistrationStepDefinition {

	WebDriver driver;
	@Given("^User is on registration page$")
	public void user_is_on_registration_page() throws Throwable {
		driver=RegistrationPOM.getWebDriver();
		String url = "C:\\BDDAnitha\\SamplePaperAutomation\\html\\registration.html";
		driver.get(url);
	}

	@When("^User Enter the full name \"([^\"]*)\"$")
	public void user_Enter_the_full_name(String name) throws Throwable {
		WebElement nameField=RegistrationPOM.getFullName();
		nameField.sendKeys(name);
	}

	@When("^User Enter email \"([^\"]*)\"$")
	public void user_Enter_email(String email) throws Throwable {
		WebElement emailField=RegistrationPOM.getEmail();
		emailField.sendKeys(email);
	}

	@When("^User Enter mobileNO \"([^\"]*)\"$")
	public void user_Enter_mobileNO(String phone) throws Throwable {
		WebElement mobile=RegistrationPOM.getMobileNo();
		mobile.sendKeys(phone);
	}

	@When("^User Select Gender$")
	public void user_Select_Gender() throws Throwable {
	    WebElement gender = RegistrationPOM.getgender();
	    gender.click();
	    
	    //Select se=new Select(gender);
	    
	    //se.selectByValue("Female");
	}//html/body/div/div/form/table/tbody/tr[5]/td[2]
	//

	@When("^User select city$")
	public void user_select_city() throws Throwable {
		WebElement city = RegistrationPOM.getCity();
	    city.click();
	    Select se=new Select(city);
	    se.selectByValue("Pune");
	}

	@When("^User select state$")
	public void user_select_state() throws Throwable {
		WebElement state = RegistrationPOM.getState();
	    state.click();
	    Select se=new Select(state);
	    se.selectByValue("Maharashtra");
	}

	@When("^User Enter subject_category \"([^\"]*)\"$")
	public void user_Enter_subject_category(String category) throws Throwable {
		WebElement subject=RegistrationPOM.getSubjectCategory();
		subject.sendKeys(category);
	}

	@When("^User Enter Paper name as \"([^\"]*)\"$")
	public void user_Enter_Paper_name_as(String name) throws Throwable {
		WebElement paper=RegistrationPOM.getPaperName();
		paper.sendKeys(name);
	}

	@When("^User Enter No_OF_AUTHORS \"([^\"]*)\"$")
	public void user_Enter_No_OF_AUTHORS(String num) throws Throwable {
		WebElement authors=RegistrationPOM.getAuthors();
		authors.sendKeys(num);
	}

	@When("^User Enter Company name \"([^\"]*)\"$")
	public void user_Enter_Company_name(String name) throws Throwable {
		WebElement company=RegistrationPOM.getCompany();
		company.sendKeys(name);
	}

	@When("^User Enter Designation \"([^\"]*)\"$")
	public void user_Enter_Designation(String designation) throws Throwable {
		WebElement company=RegistrationPOM.getDesignation();
		company.sendKeys(designation);
	}

	@Then("^Confirm Registration$")
	public void confirm_Registration() throws Throwable {
		WebElement btn=RegistrationPOM.submit();
		btn.click();
		//driver.switchTo().alert().accept();
		driver.close();
	}
	@When("^User does not Select any Gender$")
	public void user_does_not_Select_any_Gender() throws Throwable {
		WebElement gender = RegistrationPOM.getgender();
		/*JavascriptExecutor jse=(JavascriptExecutor) driver;
		jse.executeScript("alert('Please Enter Gender')");
		*/

	}
	@When("^User does not select city$")
	public void user_does_not_select_city() throws Throwable {
		WebElement city = RegistrationPOM.getCity();
	    city.click();
	}

	@When("^User does not select state$")
	public void user_does_not_select_state() throws Throwable {
		WebElement state = RegistrationPOM.getState();
	    state.click();
	}
	@Then("^Unsuccessful Registration$")
	public void unsuccessful_Registration() throws Throwable {
		WebElement btn=RegistrationPOM.submit();
		btn.click();
		driver.switchTo().alert().accept();
		driver.close();
	}



}
