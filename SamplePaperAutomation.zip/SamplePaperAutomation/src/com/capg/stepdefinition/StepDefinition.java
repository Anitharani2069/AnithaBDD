package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.LoginPOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver driver;
	@Given("^Open any browser and enter login URL$")
	public void open_any_browser_and_enter_login_URL() throws Throwable {
		driver=LoginPOM.getWebDriver();
		String url = "C:\\BDDAnitha\\SamplePaperAutomation\\html\\login.html";
		driver.get(url);
	}

	@When("^User Enters username  \"([^\"]*)\" and password  \"([^\"]*)\"$")
	public void user_Enters_username_and_password(String user, String password) throws Throwable  {
		WebElement username = LoginPOM.getUserField();

		username.sendKeys(user);
		WebElement passfield = LoginPOM.getPasswordField();

		passfield.sendKeys(password);

	    		
	}

	@Then("^login to the page$")
	public void login_to_the_page() throws Throwable {
		WebElement btn=LoginPOM.getLoginButton();
		btn.click();
		driver.close();
	}
	@Given("^open any browser and enter invalid login URL$")
	public void open_any_browser_and_enter_invalid_login_URL() throws Throwable {
		driver=LoginPOM.getWebDriver();
		String url = "C:\\BDDAnitha\\SamplePaperAutomation\\html\\login.html";
		driver.get(url);
	}
	
	@When("^User enter invalid username \"([^\"]*)\" and password \"([^\"]*)\"$")
	public void user_enter_invalid_username_and_password(String user, String password) throws Throwable {
		WebElement username = LoginPOM.getUserField();

		username.sendKeys(user);
		WebElement passfield = LoginPOM.getPasswordField();

		passfield.sendKeys(password);
	}

	@Then("^Login unsuccessful$")
	public void login_unsuccessful() throws Throwable {
		WebElement btn=LoginPOM.getLoginButton();
		btn.click();
		driver.switchTo().alert().accept();
		driver.close();
	}
	
	@Given("^User is on the login page$")
	public void user_is_on_the_login_page() throws Throwable {
		driver=LoginPOM.getWebDriver();
		String url = "C:\\BDDAnitha\\SamplePaperAutomation\\html\\login.html";
		driver.get(url);
	}

	@When("^User click on the link$")
	public void user_click_on_the_link() throws Throwable {
	    WebElement link=LoginPOM.getLink();
	    link.click();
	}

	@Then("^Open the topics page and come back$")
	public void open_the_topics_page_and_come_back() throws Throwable {
		 WebElement link=LoginPOM.getBackLink();
		 link.click();
		 driver.close();
	}

}
