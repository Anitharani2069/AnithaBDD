package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RegistrationPOM {

	
	static WebDriver driver;
	public static WebDriver getWebDriver()
	{
		/*String path = "C:\\chrome\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();	
		LoginPOM.driver=driver;*/
		driver=WebUtil.getWebDriver();
		return driver;
	}
	
	public static WebElement getFullName()
	{
		return driver.findElement(By.id("txtFullName"));
	}
	public static WebElement getEmail()
	{
		return driver.findElement(By.id("txtEmail"));
	}
	public static WebElement getMobileNo()
	{
		return driver.findElement(By.id("txtPhone"));
	}
	
	public static WebElement getgender()
	{
		return driver.findElement(By.id("genderF"));
	}
	public static WebElement getCity()
	{
		WebElement city=driver.findElement(By.name("city"));

		return city;
	}
	public static WebElement getState()
	{
		WebElement state=driver.findElement(By.name("state"));

		return state;
	}
	public static WebElement getSubjectCategory()
	{
		return driver.findElement(By.id("txtCardholderName"));
	}
	public static WebElement getPaperName()
	{
		return driver.findElement(By.id("txtDebit"));
	}
	
	public static WebElement getAuthors()
	{
		return driver.findElement(By.id("txtCvv"));
	}
	
	public static WebElement getCompany()
	{
		
		return driver.findElement(By.id("txtMonth"));
	}
	
	public static WebElement getDesignation()
	{
		return driver.findElement(By.id("txtYear"));
	}
	
	public static WebElement submit()
	{
		return driver.findElement(By.id("btnPayment"));
	}
	
	
	
	
}
