package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;


public class LoginPOM {
	
	static WebDriver driver;
	public static WebDriver getWebDriver()
	{
		/*String path = "C:\\chrome\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver = new ChromeDriver();	
		LoginPOM.driver=driver;*/
		driver=WebUtil.getWebDriver();
		return driver;
	}
	
	public static WebElement getUserField()
	{
		return driver.findElement(By.name("userName"));
		
	}
	public static WebElement getPasswordField()
	{
		return driver.findElement(By.name("userPwd"));
		
	}
	public static  WebElement getLoginButton()
	{
		return driver.findElement(By.className("btn"));
		
	}
	public static WebElement getLink()
	{
		return driver.findElement(By.partialLinkText("Click here to know the Subject Categories"));
	}
	
	public static WebElement getBackLink()
    {
        return driver.findElement(By.partialLinkText("back"));

 

    }
	
	
	


}
