package com.capg_;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebUtil {
	
	public static WebDriver getWebDriver() {
		
		String path = "C:\\drivers\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver =  new ChromeDriver();
		return driver;
		
	}

}
